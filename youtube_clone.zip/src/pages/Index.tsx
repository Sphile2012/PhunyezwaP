import React, { useState, useMemo } from 'react';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { CategoryFilter } from '@/components/CategoryFilter';
import { VideoGrid } from '@/components/VideoGrid';
import { VideoPlayer } from '@/components/VideoPlayer';
import { mockVideos, Video } from '@/data/mockVideos';
import { cn } from '@/lib/utils';

const Index = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

  // Filter videos based on category and search query
  const filteredVideos = useMemo(() => {
    let filtered = mockVideos;

    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(video => video.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(video =>
        video.title.toLowerCase().includes(query) ||
        video.channel.toLowerCase().includes(query) ||
        video.description.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [selectedCategory, searchQuery]);

  const handleMenuClick = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleSidebarClose = () => {
    setIsSidebarOpen(false);
  };

  const handleVideoClick = (video: Video) => {
    setSelectedVideo(video);
  };

  const handleBackToHome = () => {
    setSelectedVideo(null);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setSelectedVideo(null); // Go back to home when selecting category
  };

  if (selectedVideo) {
    return (
      <div className="min-h-screen bg-white">
        <Header
          onMenuClick={handleMenuClick}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        <VideoPlayer
          video={selectedVideo}
          onBack={handleBackToHome}
          onVideoClick={handleVideoClick}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header
        onMenuClick={handleMenuClick}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={handleSidebarClose}
        selectedCategory={selectedCategory}
        onCategorySelect={handleCategorySelect}
      />

      {/* Main content */}
      <main className={cn(
        "transition-all duration-300 ease-in-out",
        "lg:ml-64", // Always leave space for sidebar on desktop
        "pt-14" // Account for fixed header
      )}>
        <CategoryFilter
          selectedCategory={selectedCategory}
          onCategorySelect={handleCategorySelect}
        />
        
        <VideoGrid
          videos={filteredVideos}
          onVideoClick={handleVideoClick}
        />
      </main>
    </div>
  );
};

export default Index;