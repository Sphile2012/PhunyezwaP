export interface Video {
  id: string;
  title: string;
  channel: string;
  channelAvatar: string;
  thumbnail: string;
  views: string;
  uploadTime: string;
  duration: string;
  description: string;
  likes: number;
  dislikes: number;
  category: string;
}

export const mockVideos: Video[] = [
  // Tech Videos
  {
    id: "1",
    title: "Complete React Tutorial for Beginners 2024",
    channel: "CodeMaster",
    channelAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_1.jpeg",
    views: "1.2M",
    uploadTime: "2 days ago",
    duration: "45:32",
    description: "Learn React from scratch with this comprehensive tutorial covering all the basics and advanced concepts.",
    likes: 45000,
    dislikes: 1200,
    category: "Technology"
  },
  {
    id: "2",
    title: "JavaScript ES6+ Features You Must Know",
    channel: "WebDev Pro",
    channelAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_2.jpeg",
    views: "850K",
    uploadTime: "1 week ago",
    duration: "28:15",
    description: "Explore the latest JavaScript features that every developer should know in 2024.",
    likes: 32000,
    dislikes: 800,
    category: "Technology"
  },
  {
    id: "3",
    title: "Building Full Stack Apps with Node.js",
    channel: "FullStack Academy",
    channelAvatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_3.jpeg",
    views: "2.1M",
    uploadTime: "3 days ago",
    duration: "1:12:45",
    description: "Complete guide to building modern full-stack applications using Node.js and Express.",
    likes: 78000,
    dislikes: 2100,
    category: "Technology"
  },
  {
    id: "4",
    title: "Python Programming Masterclass",
    channel: "PythonGuru",
    channelAvatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_4.jpeg",
    views: "3.5M",
    uploadTime: "5 days ago",
    duration: "2:15:30",
    description: "Master Python programming with this comprehensive course covering basics to advanced topics.",
    likes: 125000,
    dislikes: 3200,
    category: "Technology"
  },
  
  // Gaming Videos
  {
    id: "5",
    title: "Epic Gaming Moments Compilation 2024",
    channel: "GameHighlights",
    channelAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/gaming_thumbnails_1.jpeg",
    views: "5.2M",
    uploadTime: "1 day ago",
    duration: "15:42",
    description: "The most epic gaming moments from popular streamers and gamers in 2024.",
    likes: 180000,
    dislikes: 4500,
    category: "Gaming"
  },
  {
    id: "6",
    title: "New Game Review: Latest AAA Title",
    channel: "GameReviewer",
    channelAvatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/gaming_thumbnails_2.png",
    views: "1.8M",
    uploadTime: "4 hours ago",
    duration: "22:18",
    description: "In-depth review of the latest AAA gaming title with gameplay footage and honest opinions.",
    likes: 65000,
    dislikes: 1800,
    category: "Gaming"
  },
  {
    id: "7",
    title: "Pro Gaming Tips and Tricks",
    channel: "ProGamer",
    channelAvatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671d66?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/gaming_thumbnails_3.jpeg",
    views: "920K",
    uploadTime: "2 weeks ago",
    duration: "18:55",
    description: "Level up your gaming skills with these professional tips and strategies.",
    likes: 42000,
    dislikes: 1100,
    category: "Gaming"
  },
  {
    id: "8",
    title: "Gaming Setup Tour 2024",
    channel: "TechGamer",
    channelAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/gaming_thumbnails_4.png",
    views: "2.7M",
    uploadTime: "1 week ago",
    duration: "12:33",
    description: "Tour of my ultimate gaming setup with all the latest gear and peripherals.",
    likes: 95000,
    dislikes: 2400,
    category: "Gaming"
  },

  // Lifestyle Videos
  {
    id: "9",
    title: "Morning Routine for Productivity",
    channel: "LifestyleGuru",
    channelAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/lifestyle_thumbnails_1.jpeg",
    views: "1.5M",
    uploadTime: "3 days ago",
    duration: "10:25",
    description: "Transform your mornings with this productive routine that will change your life.",
    likes: 58000,
    dislikes: 1500,
    category: "Lifestyle"
  },
  {
    id: "10",
    title: "Healthy Meal Prep Ideas",
    channel: "HealthyLiving",
    channelAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/lifestyle_thumbnails_2.jpeg",
    views: "2.3M",
    uploadTime: "5 days ago",
    duration: "16:40",
    description: "Easy and delicious meal prep ideas for a healthier lifestyle.",
    likes: 87000,
    dislikes: 2200,
    category: "Lifestyle"
  },
  {
    id: "11",
    title: "Home Decor on a Budget",
    channel: "HomeDesigner",
    channelAvatar: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/lifestyle_thumbnails_3.jpeg",
    views: "1.1M",
    uploadTime: "1 week ago",
    duration: "14:22",
    description: "Transform your home with these budget-friendly decorating tips and DIY projects.",
    likes: 48000,
    dislikes: 1200,
    category: "Lifestyle"
  },
  {
    id: "12",
    title: "Fashion Trends 2024",
    channel: "StyleIcon",
    channelAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/lifestyle_thumbnails_4.jpeg",
    views: "3.1M",
    uploadTime: "2 days ago",
    duration: "20:15",
    description: "Stay ahead of the fashion curve with the hottest trends for 2024.",
    likes: 112000,
    dislikes: 2800,
    category: "Lifestyle"
  },

  // Additional videos for variety
  {
    id: "13",
    title: "Advanced CSS Grid Techniques",
    channel: "CSSMaster",
    channelAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_5.jpeg",
    views: "680K",
    uploadTime: "4 days ago",
    duration: "35:18",
    description: "Master CSS Grid with advanced techniques and real-world examples.",
    likes: 28000,
    dislikes: 750,
    category: "Technology"
  },
  {
    id: "14",
    title: "Mobile Game Development Tutorial",
    channel: "GameDev Studio",
    channelAvatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/tech_thumbnails_6.jpeg",
    views: "1.4M",
    uploadTime: "6 days ago",
    duration: "52:30",
    description: "Learn how to create mobile games from scratch using Unity and C#.",
    likes: 62000,
    dislikes: 1600,
    category: "Technology"
  },
  {
    id: "15",
    title: "Fitness Journey Transformation",
    channel: "FitLife",
    channelAvatar: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/lifestyle_thumbnails_5.jpeg",
    views: "2.8M",
    uploadTime: "1 day ago",
    duration: "8:45",
    description: "My incredible fitness transformation journey and the lessons I learned.",
    likes: 98000,
    dislikes: 2500,
    category: "Lifestyle"
  },
  {
    id: "16",
    title: "Ultimate Gaming Chair Review",
    channel: "TechReviews",
    channelAvatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
    thumbnail: "/images/gaming_thumbnails_5.jpeg",
    views: "1.6M",
    uploadTime: "3 days ago",
    duration: "19:12",
    description: "Comprehensive review of the best gaming chairs in 2024.",
    likes: 71000,
    dislikes: 1900,
    category: "Gaming"
  }
];

export const categories = [
  "All",
  "Technology",
  "Gaming", 
  "Lifestyle",
  "Music",
  "Sports",
  "News",
  "Entertainment"
];