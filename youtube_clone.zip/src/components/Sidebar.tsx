import React from 'react';
import { Home, Compass, PlaySquare, Clock, ThumbsUp, Flame, Music, Gamepad2, Trophy, Lightbulb, Shirt, Podcast, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
}

const sidebarItems = [
  { icon: Home, label: 'Home', category: 'All' },
  { icon: Compass, label: 'Explore', category: 'All' },
  { icon: PlaySquare, label: 'Subscriptions', category: 'All' },
];

const libraryItems = [
  { icon: Clock, label: 'Watch Later', category: 'All' },
  { icon: ThumbsUp, label: 'Liked Videos', category: 'All' },
];

const exploreItems = [
  { icon: Flame, label: 'Trending', category: 'All' },
  { icon: Music, label: 'Music', category: 'Music' },
  { icon: Gamepad2, label: 'Gaming', category: 'Gaming' },
  { icon: Trophy, label: 'Sports', category: 'Sports' },
  { icon: Lightbulb, label: 'Technology', category: 'Technology' },
  { icon: Shirt, label: 'Lifestyle', category: 'Lifestyle' },
  { icon: Podcast, label: 'Entertainment', category: 'Entertainment' },
];

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, selectedCategory, onCategorySelect }) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-14 h-[calc(100vh-3.5rem)] bg-white z-50 transition-transform duration-300 ease-in-out overflow-y-auto",
        "w-64 border-r border-gray-200",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Mobile close button */}
        <div className="lg:hidden flex justify-end p-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="px-3 py-2">
          {/* Main navigation */}
          <div className="space-y-1 mb-4">
            {sidebarItems.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className={cn(
                  "w-full justify-start px-3 py-2 h-10 text-sm font-normal",
                  selectedCategory === item.category && item.label === 'Home' 
                    ? "bg-gray-100 font-medium" 
                    : "hover:bg-gray-100"
                )}
                onClick={() => {
                  onCategorySelect(item.category);
                  if (window.innerWidth < 1024) onClose();
                }}
              >
                <item.icon className="h-5 w-5 mr-6" />
                {item.label}
              </Button>
            ))}
          </div>

          <hr className="border-gray-200 mb-4" />

          {/* Library */}
          <div className="space-y-1 mb-4">
            <h3 className="px-3 text-sm font-medium text-gray-600 mb-2">Library</h3>
            {libraryItems.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className="w-full justify-start px-3 py-2 h-10 text-sm font-normal hover:bg-gray-100"
                onClick={() => {
                  if (window.innerWidth < 1024) onClose();
                }}
              >
                <item.icon className="h-5 w-5 mr-6" />
                {item.label}
              </Button>
            ))}
          </div>

          <hr className="border-gray-200 mb-4" />

          {/* Explore */}
          <div className="space-y-1">
            <h3 className="px-3 text-sm font-medium text-gray-600 mb-2">Explore</h3>
            {exploreItems.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className={cn(
                  "w-full justify-start px-3 py-2 h-10 text-sm font-normal",
                  selectedCategory === item.category 
                    ? "bg-gray-100 font-medium" 
                    : "hover:bg-gray-100"
                )}
                onClick={() => {
                  onCategorySelect(item.category);
                  if (window.innerWidth < 1024) onClose();
                }}
              >
                <item.icon className="h-5 w-5 mr-6" />
                {item.label}
              </Button>
            ))}
          </div>
        </div>
      </aside>
    </>
  );
};