import React, { useState } from 'react';
import { ArrowLeft, ThumbsUp, ThumbsDown, Share, Download, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Video, mockVideos } from '@/data/mockVideos';
import { VideoCard } from './VideoCard';
import { cn } from '@/lib/utils';

interface VideoPlayerProps {
  video: Video;
  onBack: () => void;
  onVideoClick: (video: Video) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ video, onBack, onVideoClick }) => {
  const [likes, setLikes] = useState(video.likes);
  const [dislikes, setDislikes] = useState(video.dislikes);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);

  // Get recommended videos (exclude current video)
  const recommendedVideos = mockVideos.filter(v => v.id !== video.id).slice(0, 12);

  const handleLike = () => {
    if (isLiked) {
      setLikes(likes - 1);
      setIsLiked(false);
    } else {
      setLikes(likes + 1);
      setIsLiked(true);
      if (isDisliked) {
        setDislikes(dislikes - 1);
        setIsDisliked(false);
      }
    }
  };

  const handleDislike = () => {
    if (isDisliked) {
      setDislikes(dislikes - 1);
      setIsDisliked(false);
    } else {
      setDislikes(dislikes + 1);
      setIsDisliked(true);
      if (isLiked) {
        setLikes(likes - 1);
        setIsLiked(false);
      }
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Mobile back button */}
      <div className="lg:hidden sticky top-14 bg-white border-b border-gray-200 p-4 z-30">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 p-4 pt-0 lg:pt-4">
        {/* Main content */}
        <div className="flex-1 max-w-4xl">
          {/* Video player placeholder */}
          <div className="aspect-video bg-black rounded-lg mb-4 relative overflow-hidden">
            <img
              src={video.thumbnail}
              alt={video.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-red-700 transition-colors">
                <span className="text-white text-2xl ml-1">▶</span>
              </div>
            </div>
          </div>

          {/* Video title */}
          <h1 className="text-xl font-semibold mb-4 text-gray-900">
            {video.title}
          </h1>

          {/* Video stats and actions */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 space-y-3 sm:space-y-0">
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span>{video.views} views</span>
              <span>•</span>
              <span>{video.uploadTime}</span>
            </div>

            <div className="flex items-center space-x-2">
              <div className="flex items-center bg-gray-100 rounded-full">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLike}
                  className={cn(
                    "px-4 py-2 rounded-l-full hover:bg-gray-200",
                    isLiked && "text-blue-600"
                  )}
                >
                  <ThumbsUp className="h-4 w-4 mr-2" />
                  {formatNumber(likes)}
                </Button>
                <div className="w-px h-6 bg-gray-300" />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDislike}
                  className={cn(
                    "px-4 py-2 rounded-r-full hover:bg-gray-200",
                    isDisliked && "text-blue-600"
                  )}
                >
                  <ThumbsDown className="h-4 w-4 mr-2" />
                  {formatNumber(dislikes)}
                </Button>
              </div>

              <Button variant="ghost" size="sm" className="px-4 py-2 bg-gray-100 rounded-full hover:bg-gray-200">
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>

              <Button variant="ghost" size="sm" className="px-4 py-2 bg-gray-100 rounded-full hover:bg-gray-200">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>

              <Button variant="ghost" size="sm" className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Channel info and description */}
          <div className="border-t border-gray-200 pt-4">
            <div className="flex items-start space-x-4 mb-4">
              <img
                src={video.channelAvatar}
                alt={video.channel}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <h3 className="font-medium text-gray-900">{video.channel}</h3>
                <p className="text-sm text-gray-600">1.2M subscribers</p>
              </div>
              <Button className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-full">
                Subscribe
              </Button>
            </div>

            <div className="bg-gray-100 rounded-lg p-4">
              <p className={cn(
                "text-sm text-gray-700",
                !showFullDescription && "line-clamp-3"
              )}>
                {video.description}
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowFullDescription(!showFullDescription)}
                className="mt-2 text-sm font-medium text-gray-600 hover:text-gray-900"
              >
                {showFullDescription ? 'Show less' : 'Show more'}
              </Button>
            </div>
          </div>
        </div>

        {/* Recommendations sidebar */}
        <div className="lg:w-96 lg:flex-shrink-0">
          <h2 className="text-lg font-semibold mb-4 text-gray-900">Recommended</h2>
          <div className="space-y-4">
            {recommendedVideos.map((recommendedVideo) => (
              <div
                key={recommendedVideo.id}
                className="flex space-x-3 cursor-pointer group"
                onClick={() => onVideoClick(recommendedVideo)}
              >
                <div className="relative w-40 aspect-video rounded-lg overflow-hidden bg-gray-200 flex-shrink-0">
                  <img
                    src={recommendedVideo.thumbnail}
                    alt={recommendedVideo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    loading="lazy"
                  />
                  <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 py-0.5 rounded">
                    {recommendedVideo.duration}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-sm line-clamp-2 text-gray-900 mb-1 group-hover:text-blue-600">
                    {recommendedVideo.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-1">{recommendedVideo.channel}</p>
                  <div className="flex items-center text-xs text-gray-600 space-x-1">
                    <span>{recommendedVideo.views} views</span>
                    <span>•</span>
                    <span>{recommendedVideo.uploadTime}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};