import React from 'react';
import { categories } from '@/data/mockVideos';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface CategoryFilterProps {
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({ selectedCategory, onCategorySelect }) => {
  return (
    <div className="sticky top-14 bg-white border-b border-gray-200 z-30">
      <div className="flex space-x-3 px-4 py-3 overflow-x-auto scrollbar-hide">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "secondary"}
            size="sm"
            className={cn(
              "whitespace-nowrap px-4 py-2 text-sm font-medium rounded-full flex-shrink-0",
              selectedCategory === category
                ? "bg-black text-white hover:bg-gray-800"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            )}
            onClick={() => onCategorySelect(category)}
          >
            {category}
          </Button>
        ))}
      </div>
    </div>
  );
};