import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  SlidersHorizontal, 
  Home, 
  Building2, 
  TreePine, 
  Waves, 
  Mountain,
  UtensilsCrossed,
  Car,
  Wifi,
  AirVent
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Slider } from "./ui/slider";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { useState } from "react";

const propertyTypes = [
  { id: "apartment", icon: Building2, label: "Apartment" },
  { id: "house", icon: Home, label: "House" },
  { id: "cabin", icon: TreePine, label: "Cabin" },
  { id: "beachfront", icon: Waves, label: "Beachfront" },
  { id: "mountain", icon: Mountain, label: "Mountain" },
];

const amenities = [
  { id: "wifi", icon: Wifi, label: "Wifi" },
  { id: "kitchen", icon: UtensilsCrossed, label: "Kitchen" },
  { id: "parking", icon: Car, label: "Free parking" },
  { id: "ac", icon: AirVent, label: "Air conditioning" },
];

export function FilterBar() {
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([50, 500]);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

  const toggleType = (typeId: string) => {
    setSelectedTypes(prev => 
      prev.includes(typeId) 
        ? prev.filter(id => id !== typeId)
        : [...prev, typeId]
    );
  };

  const toggleAmenity = (amenityId: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenityId) 
        ? prev.filter(id => id !== amenityId)
        : [...prev, amenityId]
    );
  };

  const activeFiltersCount = selectedTypes.length + selectedAmenities.length;

  return (
    <div className="border-b border-gray-200 bg-white sticky top-20 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Property Type Filters */}
        <div className="flex items-center space-x-6 py-4 overflow-x-auto scrollbar-hide">
          {propertyTypes.map((type) => {
            const Icon = type.icon;
            const isSelected = selectedTypes.includes(type.id);
            return (
              <Button
                key={type.id}
                variant="ghost"
                onClick={() => toggleType(type.id)}
                className={`flex flex-col items-center space-y-2 min-w-[80px] h-auto py-3 px-4 rounded-lg transition-colors duration-200 ${
                  isSelected 
                    ? 'bg-gray-100 border-2 border-gray-800' 
                    : 'border-2 border-transparent hover:bg-gray-50'
                }`}
              >
                <Icon className={`h-6 w-6 ${isSelected ? 'text-gray-800' : 'text-gray-600'}`} />
                <span className={`text-xs ${isSelected ? 'text-gray-800 font-medium' : 'text-gray-600'}`}>
                  {type.label}
                </span>
              </Button>
            );
          })}

          {/* Advanced Filters */}
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                className="flex items-center space-x-2 min-w-[120px] border-gray-300 hover:border-gray-800"
              >
                <SlidersHorizontal className="h-4 w-4" />
                <span>Filters</span>
                {activeFiltersCount > 0 && (
                  <Badge variant="secondary" className="ml-1 bg-gray-800 text-white">
                    {activeFiltersCount}
                  </Badge>
                )}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Filters</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-8 py-4">
                {/* Price Range */}
                <div>
                  <h3 className="font-semibold mb-4">Price range</h3>
                  <div className="px-3">
                    <Slider
                      value={priceRange}
                      onValueChange={setPriceRange}
                      max={1000}
                      min={10}
                      step={10}
                      className="w-full"
                    />
                    <div className="flex justify-between mt-3 text-sm text-gray-600">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}+</span>
                    </div>
                  </div>
                </div>

                {/* Amenities */}
                <div>
                  <h3 className="font-semibold mb-4">Amenities</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {amenities.map((amenity) => {
                      const Icon = amenity.icon;
                      const isSelected = selectedAmenities.includes(amenity.id);
                      return (
                        <div key={amenity.id} className="flex items-center space-x-3">
                          <Checkbox 
                            id={amenity.id}
                            checked={isSelected}
                            onCheckedChange={() => toggleAmenity(amenity.id)}
                          />
                          <Label 
                            htmlFor={amenity.id} 
                            className="flex items-center space-x-2 cursor-pointer"
                          >
                            <Icon className="h-4 w-4 text-gray-600" />
                            <span>{amenity.label}</span>
                          </Label>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-between pt-6 border-t">
                  <Button 
                    variant="ghost" 
                    onClick={() => {
                      setSelectedTypes([]);
                      setSelectedAmenities([]);
                      setPriceRange([50, 500]);
                    }}
                  >
                    Clear all
                  </Button>
                  <Button className="bg-gray-800 hover:bg-gray-900 text-white">
                    Show places
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}