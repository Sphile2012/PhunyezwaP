import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Heart, Star } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface PropertyCardProps {
  id: string;
  title: string;
  location: string;
  price: number;
  rating: number;
  reviewCount: number;
  images: string[];
  type: string;
  isNew?: boolean;
  isSuperhost?: boolean;
}

export function PropertyCard({
  title,
  location,
  price,
  rating,
  reviewCount,
  images,
  type,
  isNew,
  isSuperhost
}: PropertyCardProps) {
  return (
    <Card className="group cursor-pointer border-0 shadow-none hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <div className="aspect-square overflow-hidden rounded-xl">
          <ImageWithFallback
            src={images[0]}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-3 right-3 h-8 w-8 rounded-full bg-white/80 hover:bg-white hover:scale-110 transition-all duration-200 p-0"
        >
          <Heart className="h-4 w-4 text-gray-600" />
        </Button>
        {isNew && (
          <Badge className="absolute top-3 left-3 bg-white text-gray-800 hover:bg-white">
            New
          </Badge>
        )}
        {isSuperhost && (
          <Badge className="absolute bottom-3 left-3 bg-white text-gray-800 hover:bg-white">
            Superhost
          </Badge>
        )}
      </div>
      
      <div className="pt-3 space-y-1">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900 line-clamp-1">{location}</h3>
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 fill-current text-gray-900" />
            <span className="text-sm text-gray-900">{rating}</span>
            <span className="text-sm text-gray-500">({reviewCount})</span>
          </div>
        </div>
        
        <p className="text-gray-500 text-sm line-clamp-1">{title}</p>
        <p className="text-gray-500 text-sm">{type}</p>
        
        <div className="pt-1">
          <span className="font-semibold text-gray-900">${price}</span>
          <span className="text-gray-500 text-sm"> night</span>
        </div>
      </div>
    </Card>
  );
}