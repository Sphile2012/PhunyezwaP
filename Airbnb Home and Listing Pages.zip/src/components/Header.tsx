import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { 
  Search, 
  Globe, 
  Menu, 
  User,
  MapPin,
  Calendar,
  Users
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-[#FF5A5F] rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <span className="text-[#FF5A5F] text-xl font-semibold">airbnb</span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex items-center bg-white border border-gray-300 rounded-full shadow-sm hover:shadow-md transition-shadow duration-200 max-w-2xl flex-1 mx-8">
            <div className="flex items-center divide-x divide-gray-300">
              <div className="flex items-center px-6 py-3">
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-gray-800">Where</span>
                  <input 
                    type="text" 
                    placeholder="Search destinations" 
                    className="text-sm text-gray-600 bg-transparent border-none outline-none placeholder-gray-400"
                  />
                </div>
              </div>
              <div className="flex items-center px-6 py-3">
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-gray-800">Check in</span>
                  <span className="text-sm text-gray-400">Add dates</span>
                </div>
              </div>
              <div className="flex items-center px-6 py-3">
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-gray-800">Check out</span>
                  <span className="text-sm text-gray-400">Add dates</span>
                </div>
              </div>
              <div className="flex items-center px-6 py-3">
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-gray-800">Who</span>
                  <span className="text-sm text-gray-400">Add guests</span>
                </div>
              </div>
            </div>
            <Button size="sm" className="bg-[#FF5A5F] hover:bg-[#E00007] text-white rounded-full h-12 w-12 mr-2">
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="text-gray-700 hover:bg-gray-100 rounded-full px-3 py-2">
              Airbnb your home
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-700 hover:bg-gray-100 rounded-full p-3">
              <Globe className="h-4 w-4" />
            </Button>
            
            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2 rounded-full border-gray-300 hover:shadow-md transition-shadow duration-200 px-2 py-1">
                  <Menu className="h-4 w-4" />
                  <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem>Sign up</DropdownMenuItem>
                <DropdownMenuItem>Log in</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Airbnb your home</DropdownMenuItem>
                <DropdownMenuItem>Host an experience</DropdownMenuItem>
                <DropdownMenuItem>Help Center</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Mobile Search */}
      <div className="md:hidden px-4 pb-4">
        <div className="flex items-center bg-white border border-gray-300 rounded-full shadow-sm p-3">
          <Search className="h-5 w-5 text-gray-400 mr-3" />
          <div className="flex-1">
            <div className="text-sm font-semibold text-gray-800">Where to?</div>
            <div className="text-xs text-gray-500">Anywhere • Any week • Add guests</div>
          </div>
        </div>
      </div>
    </header>
  );
}