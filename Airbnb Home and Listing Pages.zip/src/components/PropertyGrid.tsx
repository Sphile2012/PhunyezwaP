import { PropertyCard } from "./PropertyCard";

const mockProperties = [
  {
    id: "1",
    title: "Modern Luxury Apartment with City Views",
    location: "Downtown Manhattan, New York",
    price: 320,
    rating: 4.9,
    reviewCount: 127,
    images: ["https://images.unsplash.com/photo-1638454668466-e8dbd5462f20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsdXh1cnklMjBhcGFydG1lbnQlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NTg3ODMyMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire apartment",
    isNew: true,
    isSuperhost: true
  },
  {
    id: "2", 
    title: "Cozy Victorian House with Garden",
    location: "Brooklyn Heights, New York", 
    price: 185,
    rating: 4.7,
    reviewCount: 89,
    images: ["https://images.unsplash.com/photo-1641243418336-502b640ea5f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwaG91c2UlMjBleHRlcmlvcnxlbnwxfHx8fDE3NTg3NjAwNjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire house",
    isSuperhost: true
  },
  {
    id: "3",
    title: "Beachfront Villa with Ocean Views", 
    location: "Malibu, California",
    price: 650,
    rating: 4.8,
    reviewCount: 203,
    images: ["https://images.unsplash.com/photo-1664540972623-8e3ac6d69899?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMGhvdXNlJTIwdmFjYXRpb24lMjByZW50YWx8ZW58MXx8fHwxNzU4ODU0NjE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire villa",
    isSuperhost: true
  },
  {
    id: "4",
    title: "Mountain Cabin Retreat", 
    location: "Aspen, Colorado",
    price: 280,
    rating: 4.6,
    reviewCount: 156,
    images: ["https://images.unsplash.com/photo-1701825299870-398fb12864bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGNhYmluJTIwcmV0cmVhdHxlbnwxfHx8fDE3NTg4MDQ5MDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire cabin",
    isNew: true
  },
  {
    id: "5",
    title: "Industrial Loft in Arts District",
    location: "Downtown LA, California", 
    price: 225,
    rating: 4.5,
    reviewCount: 78,
    images: ["https://images.unsplash.com/photo-1664159302000-cef53d678f4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwbG9mdCUyMGFwYXJ0bWVudHxlbnwxfHx8fDE3NTg4NTQ2MjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire loft"
  },
  {
    id: "6",
    title: "Countryside Cottage Getaway",
    location: "Napa Valley, California",
    price: 195,
    rating: 4.9,
    reviewCount: 234,
    images: ["https://images.unsplash.com/photo-1667924599516-212cacfe3a2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3VudHJ5c2lkZSUyMGNvdHRhZ2UlMjB2YWNhdGlvbnxlbnwxfHx8fDE3NTg4NTQ2MjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire cottage",
    isSuperhost: true
  },
  {
    id: "7",
    title: "Modern Penthouse Suite",
    location: "SoHo, New York",
    price: 475,
    rating: 4.8,
    reviewCount: 167,
    images: ["https://images.unsplash.com/photo-1638454668466-e8dbd5462f20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsdXh1cnklMjBhcGFydG1lbnQlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NTg3ODMyMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Entire apartment",
    isNew: true,
    isSuperhost: true
  },
  {
    id: "8",
    title: "Charming Brownstone Apartment", 
    location: "Boston, Massachusetts",
    price: 155,
    rating: 4.4,
    reviewCount: 92,
    images: ["https://images.unsplash.com/photo-1641243418336-502b640ea5f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwaG91c2UlMjBleHRlcmlvcnxlbnwxfHx8fDE3NTg3NjAwNjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"],
    type: "Private room"
  }
];

export function PropertyGrid() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {mockProperties.map((property) => (
          <PropertyCard
            key={property.id}
            {...property}
          />
        ))}
      </div>
      
      {/* Load More */}
      <div className="text-center mt-12">
        <button className="px-8 py-3 border border-gray-800 text-gray-800 rounded-lg hover:bg-gray-800 hover:text-white transition-colors duration-200">
          Continue exploring
        </button>
      </div>
    </div>
  );
}