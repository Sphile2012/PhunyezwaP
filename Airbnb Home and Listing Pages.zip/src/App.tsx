import { Header } from "./components/Header";
import { FilterBar } from "./components/FilterBar";
import { PropertyGrid } from "./components/PropertyGrid";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <FilterBar />
      <PropertyGrid />
    </div>
  );
}