-- Update existing users to be confirmed (only email_confirmed_at)
UPDATE auth.users 
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- Create a function to auto-confirm users on signup
CREATE OR REPLACE FUNCTION public.auto_confirm_user_2025_10_12_06_21()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-confirm the user by setting email_confirmed_at
  NEW.email_confirmed_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-confirm users
DROP TRIGGER IF EXISTS auto_confirm_user_trigger_2025_10_12_06_21 ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger_2025_10_12_06_21
  BEFORE INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.auto_confirm_user_2025_10_12_06_21();