-- Enable RLS
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles_2025_10_12_06_21 (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  username TEXT UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create tweets table
CREATE TABLE IF NOT EXISTS public.tweets_2025_10_12_06_21 (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0
);

-- Create likes table
CREATE TABLE IF NOT EXISTS public.likes_2025_10_12_06_21 (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  tweet_id UUID REFERENCES public.tweets_2025_10_12_06_21(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, tweet_id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS public.comments_2025_10_12_06_21 (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  tweet_id UUID REFERENCES public.tweets_2025_10_12_06_21(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles_2025_10_12_06_21 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tweets_2025_10_12_06_21 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes_2025_10_12_06_21 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments_2025_10_12_06_21 ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles_2025_10_12_06_21
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own profile" ON public.profiles_2025_10_12_06_21
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles_2025_10_12_06_21
  FOR UPDATE USING (auth.uid() = id);

-- RLS Policies for tweets
CREATE POLICY "Tweets are viewable by everyone" ON public.tweets_2025_10_12_06_21
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own tweets" ON public.tweets_2025_10_12_06_21
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own tweets" ON public.tweets_2025_10_12_06_21
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own tweets" ON public.tweets_2025_10_12_06_21
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for likes
CREATE POLICY "Likes are viewable by everyone" ON public.likes_2025_10_12_06_21
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own likes" ON public.likes_2025_10_12_06_21
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own likes" ON public.likes_2025_10_12_06_21
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for comments
CREATE POLICY "Comments are viewable by everyone" ON public.comments_2025_10_12_06_21
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own comments" ON public.comments_2025_10_12_06_21
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments" ON public.comments_2025_10_12_06_21
  FOR DELETE USING (auth.uid() = user_id);

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user_2025_10_12_06_21()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles_2025_10_12_06_21 (id, full_name, avatar_url)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
CREATE OR REPLACE TRIGGER on_auth_user_created_2025_10_12_06_21
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user_2025_10_12_06_21();

-- Create function to update tweet counts
CREATE OR REPLACE FUNCTION public.update_tweet_likes_count_2025_10_12_06_21()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.tweets_2025_10_12_06_21 
    SET likes_count = likes_count + 1 
    WHERE id = NEW.tweet_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.tweets_2025_10_12_06_21 
    SET likes_count = likes_count - 1 
    WHERE id = OLD.tweet_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for likes count
CREATE OR REPLACE TRIGGER update_likes_count_2025_10_12_06_21
  AFTER INSERT OR DELETE ON public.likes_2025_10_12_06_21
  FOR EACH ROW EXECUTE PROCEDURE public.update_tweet_likes_count_2025_10_12_06_21();