import { useState } from 'react';
import { User } from '@supabase/supabase-js';
import Auth from '@/components/Auth';
import TweetComposer from '@/components/TweetComposer';
import TweetList from '@/components/TweetList';
import SearchBar from '@/components/SearchBar';
import TrendingSidebar from '@/components/TrendingSidebar';
import ProfilePage from '@/components/ProfilePage';
import { Button } from '@/components/ui/button';
import { Home, User as UserIcon, Search } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';

const Index = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<'home' | 'profile' | 'search'>('home');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  const handleTweetCreated = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentView('search');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <img 
              src="/images/twitter_favicon_1.jpeg" 
              alt="X Logo" 
              className="w-12 h-12 mx-auto mb-4"
            />
            <h1 className="text-3xl font-bold text-white mb-2">Welcome to X</h1>
            <p className="text-gray-400">Join the conversation</p>
          </div>
          <Auth onAuthChange={setUser} />
        </div>
        <Toaster />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-6xl mx-auto flex">
        {/* Sidebar */}
        <div className="w-64 p-4 border-r border-gray-700">
          <div className="mb-8">
            <img 
              src="/images/twitter_favicon_1.jpeg" 
              alt="X Logo" 
              className="w-8 h-8"
            />
          </div>
          
          <nav className="space-y-2">
            <Button
              variant={currentView === 'home' ? 'default' : 'ghost'}
              className="w-full justify-start text-white hover:bg-gray-800"
              onClick={() => setCurrentView('home')}
            >
              <Home className="w-6 h-6 mr-3" />
              Home
            </Button>
            
            <Button
              variant={currentView === 'profile' ? 'default' : 'ghost'}
              className="w-full justify-start text-white hover:bg-gray-800"
              onClick={() => setCurrentView('profile')}
            >
              <UserIcon className="w-6 h-6 mr-3" />
              Profile
            </Button>
          </nav>

          <div className="mt-8">
            <Auth onAuthChange={setUser} />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 max-w-2xl border-r border-gray-700">
          <div className="sticky top-0 bg-black/80 backdrop-blur border-b border-gray-700 p-4">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-white">
                {currentView === 'home' ? 'Home' : 
                 currentView === 'profile' ? 'Profile' : 'Search'}
              </h1>
              {currentView === 'home' && (
                <div className="w-64">
                  <SearchBar onSearch={handleSearch} />
                </div>
              )}
            </div>
          </div>

          <div className="p-4">
            {currentView === 'home' && (
              <>
                <TweetComposer user={user} onTweetCreated={handleTweetCreated} />
                <TweetList user={user} refreshTrigger={refreshTrigger} />
              </>
            )}
            
            {currentView === 'profile' && (
              <ProfilePage user={user} />
            )}
            
            {currentView === 'search' && (
              <div className="space-y-4">
                <div className="mb-4">
                  <SearchBar onSearch={handleSearch} />
                </div>
                <div className="text-center py-8 text-gray-400">
                  Search results for "{searchQuery}" would appear here
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-80 p-4">
          <TrendingSidebar />
        </div>
      </div>
      <Toaster />
    </div>
  );
};

export default Index;