import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const trendingTopics = [
  { topic: '#ReactJS', posts: '125K posts' },
  { topic: '#TypeScript', posts: '89K posts' },
  { topic: '#WebDevelopment', posts: '234K posts' },
  { topic: '#JavaScript', posts: '456K posts' },
  { topic: '#TailwindCSS', posts: '67K posts' },
];

export default function TrendingSidebar() {
  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-xl">What's happening</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trendingTopics.map((trend, index) => (
            <div key={index} className="hover:bg-gray-800 p-2 rounded cursor-pointer transition-colors">
              <div className="text-white font-semibold">{trend.topic}</div>
              <div className="text-gray-400 text-sm">{trend.posts}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-xl">Who to follow</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">JS</span>
              </div>
              <div>
                <div className="text-white font-semibold">JavaScript</div>
                <div className="text-gray-400 text-sm">@javascript</div>
              </div>
            </div>
            <button className="bg-white text-black px-4 py-1 rounded-full text-sm font-semibold hover:bg-gray-200 transition-colors">
              Follow
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">R</span>
              </div>
              <div>
                <div className="text-white font-semibold">React</div>
                <div className="text-gray-400 text-sm">@reactjs</div>
              </div>
            </div>
            <button className="bg-white text-black px-4 py-1 rounded-full text-sm font-semibold hover:bg-gray-200 transition-colors">
              Follow
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}