import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { User } from '@supabase/supabase-js';
import { Heart, MessageCircle, Trash2, Edit3, X, Check } from 'lucide-react';

interface Tweet {
  id: string;
  content: string;
  created_at: string;
  likes_count: number;
  user_id: string;
  profiles_2025_10_12_06_21?: {
    full_name: string;
    username: string;
    avatar_url: string;
  };
}

interface Like {
  id: string;
  user_id: string;
  tweet_id: string;
}

interface TweetListProps {
  user: User | null;
  refreshTrigger: number;
}

export default function TweetList({ user, refreshTrigger }: TweetListProps) {
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const [likes, setLikes] = useState<Like[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingTweet, setEditingTweet] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const { toast } = useToast();

  const fetchTweets = async () => {
    try {
      const { data: tweetsData, error: tweetsError } = await supabase
        .from('tweets_2025_10_12_06_21')
        .select(`
          *,
          profiles_2025_10_12_06_21 (
            full_name,
            username,
            avatar_url
          )
        `)
        .order('created_at', { ascending: false });

      if (tweetsError) throw tweetsError;

      const { data: likesData, error: likesError } = await supabase
        .from('likes_2025_10_12_06_21')
        .select('*');

      if (likesError) throw likesError;

      setTweets(tweetsData || []);
      setLikes(likesData || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTweets();
  }, [refreshTrigger]);

  const handleLike = async (tweetId: string) => {
    if (!user) return;

    const existingLike = likes.find(like => 
      like.tweet_id === tweetId && like.user_id === user.id
    );

    try {
      if (existingLike) {
        // Unlike
        const { error } = await supabase
          .from('likes_2025_10_12_06_21')
          .delete()
          .eq('id', existingLike.id);

        if (error) throw error;
      } else {
        // Like
        const { error } = await supabase
          .from('likes_2025_10_12_06_21')
          .insert([
            {
              user_id: user.id,
              tweet_id: tweetId,
            }
          ]);

        if (error) throw error;
      }

      fetchTweets(); // Refresh to get updated counts
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (tweetId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('tweets_2025_10_12_06_21')
        .delete()
        .eq('id', tweetId)
        .eq('user_id', user.id);

      if (error) throw error;

      fetchTweets();
      toast({
        title: "Tweet deleted",
        description: "Your tweet has been deleted.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEdit = (tweet: Tweet) => {
    setEditingTweet(tweet.id);
    setEditContent(tweet.content);
  };

  const handleSaveEdit = async (tweetId: string) => {
    if (!user || !editContent.trim()) return;

    try {
      const { error } = await supabase
        .from('tweets_2025_10_12_06_21')
        .update({ content: editContent.trim() })
        .eq('id', tweetId)
        .eq('user_id', user.id);

      if (error) throw error;

      setEditingTweet(null);
      setEditContent('');
      fetchTweets();
      toast({
        title: "Tweet updated",
        description: "Your tweet has been updated.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleCancelEdit = () => {
    setEditingTweet(null);
    setEditContent('');
  };

  const isLiked = (tweetId: string) => {
    return user && likes.some(like => 
      like.tweet_id === tweetId && like.user_id === user.id
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="text-gray-400">Loading tweets...</div>
      </div>
    );
  }

  if (tweets.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        No tweets yet. Be the first to post!
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tweets.map((tweet) => (
        <Card key={tweet.id} className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">
                  {tweet.profiles_2025_10_12_06_21?.full_name?.[0] || 'U'}
                </span>
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="font-semibold text-white">
                    {tweet.profiles_2025_10_12_06_21?.full_name || 'User'}
                  </span>
                  <span className="text-gray-400 text-sm">
                    @{tweet.profiles_2025_10_12_06_21?.username || 'user'}
                  </span>
                  <span className="text-gray-400 text-sm">·</span>
                  <span className="text-gray-400 text-sm">
                    {formatDate(tweet.created_at)}
                  </span>
                </div>
                
                {editingTweet === tweet.id ? (
                  <div className="space-y-3">
                    <Textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                      maxLength={280}
                    />
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        onClick={() => handleSaveEdit(tweet.id)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleCancelEdit}
                        className="border-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-white mb-3 whitespace-pre-wrap">
                    {tweet.content}
                  </p>
                )}

                <div className="flex items-center space-x-6 text-gray-400">
                  <button
                    onClick={() => handleLike(tweet.id)}
                    className={`flex items-center space-x-2 hover:text-red-400 transition-colors ${
                      isLiked(tweet.id) ? 'text-red-400' : ''
                    }`}
                    disabled={!user}
                  >
                    <Heart 
                      className={`w-5 h-5 ${isLiked(tweet.id) ? 'fill-current' : ''}`} 
                    />
                    <span>{tweet.likes_count}</span>
                  </button>
                  
                  <button className="flex items-center space-x-2 hover:text-blue-400 transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span>0</span>
                  </button>

                  {user && tweet.user_id === user.id && editingTweet !== tweet.id && (
                    <>
                      <button
                        onClick={() => handleEdit(tweet)}
                        className="flex items-center space-x-2 hover:text-blue-400 transition-colors"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      
                      <button
                        onClick={() => handleDelete(tweet.id)}
                        className="flex items-center space-x-2 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}