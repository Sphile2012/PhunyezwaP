import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { User } from '@supabase/supabase-js';

interface TweetComposerProps {
  user: User;
  onTweetCreated: () => void;
}

export default function TweetComposer({ user, onTweetCreated }: TweetComposerProps) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('tweets_2025_10_12_06_21')
        .insert([
          {
            user_id: user.id,
            content: content.trim(),
          }
        ]);

      if (error) throw error;

      setContent('');
      onTweetCreated();
      toast({
        title: "Tweet posted!",
        description: "Your tweet has been shared.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-gray-900 border-gray-700 mb-6">
      <CardContent className="p-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="What's happening?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="bg-gray-800 border-gray-600 text-white text-xl resize-none min-h-[120px]"
            maxLength={280}
          />
          <div className="flex justify-between items-center">
            <span className="text-gray-400 text-sm">
              {content.length}/280
            </span>
            <Button 
              type="submit" 
              disabled={loading || !content.trim()}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6"
            >
              {loading ? 'Posting...' : 'Post'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}