import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://swkhylqtkapyecqthtut.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN3a2h5bHF0a2FweWVjcXRodHV0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4NTI3MTMsImV4cCI6MjA3NDQyODcxM30.5J2BEQ_KHF4CeYnCwjF5lAnUtsQh_JSc9TrlwXm62g4'

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Import the supabase client like this:
// import { supabase } from "@/integrations/supabase/client";
