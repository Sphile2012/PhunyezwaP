import { Bookmark, Heart, MessageCircle, MoreHorizontal, Send, Smile } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";

interface PostProps {
  id: number;
  username: string;
  userAvatar: string;
  postImage: string;
  likes: number;
  caption: string;
  comments: number;
  timeAgo: string;
}

export function Post({
  username,
  userAvatar,
  postImage,
  likes,
  caption,
  comments,
  timeAgo,
}: PostProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [currentLikes, setCurrentLikes] = useState(likes);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setCurrentLikes(isLiked ? currentLikes - 1 : currentLikes + 1);
  };

  return (
    <article className="border-b bg-background mb-4 pb-4">
      {/* Post Header */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8 cursor-pointer">
            <AvatarImage src={userAvatar} />
            <AvatarFallback>{username[0].toUpperCase()}</AvatarFallback>
          </Avatar>
          <span className="cursor-pointer">{username}</span>
        </div>
        <button className="p-2 hover:bg-accent rounded-lg transition-colors">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>

      {/* Post Image */}
      <div className="relative aspect-square w-full bg-muted">
        <ImageWithFallback
          src={postImage}
          alt={`Post by ${username}`}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-4">
          <button
            onClick={handleLike}
            className="p-1 hover:opacity-50 transition-opacity"
          >
            <Heart
              className={`h-6 w-6 ${isLiked ? "fill-red-500 text-red-500" : ""}`}
            />
          </button>
          <button className="p-1 hover:opacity-50 transition-opacity">
            <MessageCircle className="h-6 w-6" />
          </button>
          <button className="p-1 hover:opacity-50 transition-opacity">
            <Send className="h-6 w-6" />
          </button>
        </div>
        <button
          onClick={() => setIsSaved(!isSaved)}
          className="p-1 hover:opacity-50 transition-opacity"
        >
          <Bookmark className={`h-6 w-6 ${isSaved ? "fill-foreground" : ""}`} />
        </button>
      </div>

      {/* Likes */}
      <div className="px-3 mb-2">
        <span>{currentLikes.toLocaleString()} likes</span>
      </div>

      {/* Caption */}
      <div className="px-3 mb-2">
        <span className="mr-2">{username}</span>
        <span className="text-foreground/80">{caption}</span>
      </div>

      {/* Comments */}
      {comments > 0 && (
        <button className="px-3 mb-2 text-muted-foreground hover:opacity-70">
          View all {comments} comments
        </button>
      )}

      {/* Time */}
      <div className="px-3 text-xs text-muted-foreground uppercase">
        {timeAgo}
      </div>

      {/* Add Comment */}
      <div className="flex items-center gap-3 px-3 pt-3 border-t mt-3">
        <Smile className="h-6 w-6 text-muted-foreground cursor-pointer hover:opacity-70" />
        <input
          type="text"
          placeholder="Add a comment..."
          className="flex-1 bg-transparent outline-none"
        />
        <button className="text-primary/50 hover:text-primary disabled:opacity-30">
          Post
        </button>
      </div>
    </article>
  );
}
