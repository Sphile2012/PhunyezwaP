import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

const stories = [
  {
    id: 1,
    username: "your_story",
    avatar: "https://images.unsplash.com/photo-1561740303-a0fd9fabc646?w=100",
    hasStory: true,
    isYourStory: true,
  },
  {
    id: 2,
    username: "nature_lover",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    hasStory: true,
  },
  {
    id: 3,
    username: "foodie_daily",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
    hasStory: true,
  },
  {
    id: 4,
    username: "travel_tales",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
    hasStory: true,
  },
  {
    id: 5,
    username: "urban_vibes",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100",
    hasStory: true,
  },
  {
    id: 6,
    username: "fashion_forward",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100",
    hasStory: true,
  },
  {
    id: 7,
    username: "adventure_time",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100",
    hasStory: true,
  },
  {
    id: 8,
    username: "creative_soul",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100",
    hasStory: true,
  },
];

export function Stories() {
  return (
    <div className="border-b bg-background p-4">
      <div className="mx-auto max-w-xl">
        <div className="flex gap-4 overflow-x-auto scrollbar-hide">
          {stories.map((story) => (
            <div key={story.id} className="flex flex-col items-center gap-1 min-w-fit">
              <div
                className={`rounded-full p-[2px] ${
                  story.hasStory
                    ? "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500"
                    : ""
                }`}
              >
                <div className="rounded-full p-[2px] bg-background">
                  <Avatar className="h-14 w-14 cursor-pointer">
                    <AvatarImage src={story.avatar} />
                    <AvatarFallback>{story.username[0].toUpperCase()}</AvatarFallback>
                  </Avatar>
                </div>
              </div>
              <span className="text-xs truncate max-w-[64px]">{story.username}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
