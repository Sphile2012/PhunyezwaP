import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";

const suggestions = [
  {
    id: 1,
    username: "photography_pro",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
    subtitle: "Followed by jane_doe + 2 more",
  },
  {
    id: 2,
    username: "fitness_journey",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    subtitle: "Followed by john_smith",
  },
  {
    id: 3,
    username: "art_collective",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
    subtitle: "Followed by alex_wonder + 3 more",
  },
  {
    id: 4,
    username: "tech_reviews",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100",
    subtitle: "New to Instagram",
  },
  {
    id: 5,
    username: "music_vibes",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100",
    subtitle: "Followed by sarah_lee",
  },
];

export function Suggestions() {
  return (
    <aside className="hidden xl:block w-80 p-8 sticky top-20">
      {/* Current User */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src="https://images.unsplash.com/photo-1561740303-a0fd9fabc646?w=100" />
            <AvatarFallback>ME</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">your_username</p>
            <p className="text-sm text-muted-foreground">Your Name</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" className="text-primary">
          Switch
        </Button>
      </div>

      {/* Suggestions */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-muted-foreground">Suggestions For You</span>
          <Button variant="ghost" size="sm" className="h-auto p-0 text-foreground hover:text-muted-foreground">
            See All
          </Button>
        </div>

        <div className="space-y-4">
          {suggestions.map((user) => (
            <div key={user.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{user.username[0].toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm cursor-pointer hover:opacity-70">
                    {user.username}
                  </p>
                  <p className="text-xs text-muted-foreground">{user.subtitle}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="h-auto p-0 text-primary hover:text-primary/70">
                Follow
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-xs text-muted-foreground">
        <div className="flex flex-wrap gap-2 mb-4">
          <a href="#" className="hover:underline">About</a>
          <span>·</span>
          <a href="#" className="hover:underline">Help</a>
          <span>·</span>
          <a href="#" className="hover:underline">Press</a>
          <span>·</span>
          <a href="#" className="hover:underline">API</a>
          <span>·</span>
          <a href="#" className="hover:underline">Jobs</a>
          <span>·</span>
          <a href="#" className="hover:underline">Privacy</a>
          <span>·</span>
          <a href="#" className="hover:underline">Terms</a>
        </div>
        <p>© 2025 INSTAGRAM FROM META</p>
      </div>
    </aside>
  );
}
