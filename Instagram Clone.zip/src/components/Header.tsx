import { Heart, Home, MessageCircle, PlusSquare, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Input } from "./ui/input";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center">
          <h1 className="font-['Billabong',cursive] text-[28px]">Instagram</h1>
        </div>

        {/* Search - Hidden on mobile */}
        <div className="hidden md:block flex-1 max-w-xs mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search"
              className="pl-10 bg-input-background border-0"
            />
          </div>
        </div>

        {/* Navigation Icons */}
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-accent rounded-lg transition-colors">
            <Home className="h-6 w-6" />
          </button>
          <button className="p-2 hover:bg-accent rounded-lg transition-colors">
            <MessageCircle className="h-6 w-6" />
          </button>
          <button className="p-2 hover:bg-accent rounded-lg transition-colors">
            <PlusSquare className="h-6 w-6" />
          </button>
          <button className="p-2 hover:bg-accent rounded-lg transition-colors">
            <Heart className="h-6 w-6" />
          </button>
          <Avatar className="h-8 w-8 cursor-pointer">
            <AvatarImage src="https://images.unsplash.com/photo-1561740303-a0fd9fabc646?w=100" />
            <AvatarFallback>ME</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
