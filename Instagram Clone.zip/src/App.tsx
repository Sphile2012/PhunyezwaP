import { Header } from "./components/Header";
import { Stories } from "./components/Stories";
import { Post } from "./components/Post";
import { Suggestions } from "./components/Suggestions";

const posts = [
  {
    id: 1,
    username: "nature_explorer",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
    postImage: "https://images.unsplash.com/photo-1617634667039-8e4cb277ab46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBsYW5kc2NhcGV8ZW58MXx8fHwxNzU5NzI5MTUxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 1234,
    caption: "The mountains are calling and I must go 🏔️ What an incredible view!",
    comments: 89,
    timeAgo: "2 hours ago",
  },
  {
    id: 2,
    username: "foodie_adventures",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
    postImage: "https://images.unsplash.com/photo-1532980400857-e8d9d275d858?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzU5NjkxOTY3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 2567,
    caption: "Brunch goals achieved! 🥞✨ This place never disappoints.",
    comments: 143,
    timeAgo: "4 hours ago",
  },
  {
    id: 3,
    username: "wanderlust_diaries",
    userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
    postImage: "https://images.unsplash.com/photo-1528543606781-2f6e6857f318?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzU5Njk3Nzk1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 3421,
    caption: "Adventure awaits at every corner 🌍 Exploring hidden gems around the world.",
    comments: 201,
    timeAgo: "6 hours ago",
  },
  {
    id: 4,
    username: "urban_architecture",
    userAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100",
    postImage: "https://images.unsplash.com/photo-1617381519460-d87050ddeb92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc1OTcyNTQ2OHww&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 1876,
    caption: "City lights and architectural delights 🌃 The beauty of modern design.",
    comments: 92,
    timeAgo: "8 hours ago",
  },
  {
    id: 5,
    username: "style_icon",
    userAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100",
    postImage: "https://images.unsplash.com/photo-1483985988355-763728e1935b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGV8ZW58MXx8fHwxNzU5NzU3MjI0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 4532,
    caption: "Fashion is about dressing according to what's fashionable. Style is more about being yourself. 💃",
    comments: 267,
    timeAgo: "12 hours ago",
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Stories />
      
      <div className="flex justify-center">
        {/* Main Feed */}
        <main className="w-full max-w-xl pt-8">
          {posts.map((post) => (
            <Post key={post.id} {...post} />
          ))}
        </main>

        {/* Suggestions Sidebar */}
        <Suggestions />
      </div>
    </div>
  );
}
