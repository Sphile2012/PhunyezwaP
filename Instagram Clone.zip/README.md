
  # Instagram Clone

  This is a code bundle for Instagram Clone. The original project is available at https://www.figma.com/design/jcyLugG1OU8MHoJTm8sVO7/Instagram-Clone.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  