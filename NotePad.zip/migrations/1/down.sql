
DROP INDEX idx_notes_pinned;
DROP INDEX idx_notes_created_at;
DROP TABLE notes;
