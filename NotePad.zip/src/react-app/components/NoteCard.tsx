import { useState } from 'react';
import { Pin, Archive, Trash2, MoreVertical } from 'lucide-react';
import { useDispatch } from 'react-redux';
import { updateNote, deleteNote } from '@/react-app/store/notesSlice';
import { Note } from '@/shared/types';
import { AppDispatch } from '@/react-app/store/store';

interface NoteCardProps {
  note: Note;
}

const NOTE_COLORS = [
  '#fef9c3', // yellow
  '#fecaca', // red
  '#bbf7d0', // green
  '#bfdbfe', // blue
  '#e9d5ff', // purple
  '#fed7aa', // orange
  '#fbcfe8', // pink
  '#f3f4f6', // gray
];

export default function NoteCard({ note }: NoteCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(note.title ?? '');
  const [content, setContent] = useState(note.content ?? '');
  const [showMenu, setShowMenu] = useState(false);
  const dispatch = useDispatch<AppDispatch>();

  const handleSave = () => {
    if (title !== note.title || content !== note.content) {
      dispatch(updateNote({
        id: note.id,
        updates: { title: title || undefined, content: content || undefined }
      }));
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSave();
    }
  };

  const togglePin = () => {
    dispatch(updateNote({
      id: note.id,
      updates: { is_pinned: !note.is_pinned }
    }));
  };

  const archiveNote = () => {
    dispatch(updateNote({
      id: note.id,
      updates: { is_archived: true }
    }));
  };

  const deleteNoteHandler = () => {
    dispatch(deleteNote(note.id));
  };

  const changeColor = (color: string) => {
    dispatch(updateNote({
      id: note.id,
      updates: { color }
    }));
    setShowMenu(false);
  };

  if (isEditing) {
    return (
      <div 
        className="group relative rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200 p-4"
        style={{ backgroundColor: note.color }}
      >
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onBlur={handleSave}
          onKeyDown={handleKeyDown}
          placeholder="Title"
          className="w-full bg-transparent text-lg font-medium placeholder-gray-500 border-none outline-none resize-none mb-2"
          autoFocus={!title}
        />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onBlur={handleSave}
          onKeyDown={handleKeyDown}
          placeholder="Take a note..."
          className="w-full bg-transparent placeholder-gray-500 border-none outline-none resize-none min-h-[80px]"
          autoFocus={!!title}
        />
      </div>
    );
  }

  return (
    <div 
      className="group relative rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200 p-4 cursor-pointer"
      style={{ backgroundColor: note.color }}
      onClick={() => setIsEditing(true)}
    >
      {note.is_pinned && (
        <Pin className="absolute top-2 right-2 w-4 h-4 text-gray-600 fill-current" />
      )}
      
      {note.title && (
        <h3 className="text-lg font-medium text-gray-900 mb-2 pr-8">
          {note.title}
        </h3>
      )}
      
      {note.content && (
        <p className="text-gray-700 whitespace-pre-wrap break-words">
          {note.content}
        </p>
      )}

      {/* Action buttons - shown on hover */}
      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-1">
        <button
          onClick={(e) => {
            e.stopPropagation();
            togglePin();
          }}
          className={`p-1.5 rounded-full hover:bg-black/10 transition-colors ${
            note.is_pinned ? 'text-gray-700' : 'text-gray-500'
          }`}
          title={note.is_pinned ? 'Unpin' : 'Pin'}
        >
          <Pin className="w-4 h-4" />
        </button>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            archiveNote();
          }}
          className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-gray-500"
          title="Archive"
        >
          <Archive className="w-4 h-4" />
        </button>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            deleteNoteHandler();
          }}
          className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-gray-500"
          title="Delete"
        >
          <Trash2 className="w-4 h-4" />
        </button>
        
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-gray-500"
            title="More options"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
          
          {showMenu && (
            <div className="absolute bottom-full right-0 mb-2 bg-white rounded-lg shadow-lg border border-gray-200 p-2 z-10">
              <div className="flex gap-1">
                {NOTE_COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={(e) => {
                      e.stopPropagation();
                      changeColor(color);
                    }}
                    className="w-6 h-6 rounded-full border-2 border-gray-300 hover:border-gray-400 transition-colors"
                    style={{ backgroundColor: color }}
                    title="Change color"
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
