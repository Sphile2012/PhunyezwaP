import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createNote } from '@/react-app/store/notesSlice';
import { AppDispatch } from '@/react-app/store/store';

export default function CreateNote() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const dispatch = useDispatch<AppDispatch>();

  const handleSubmit = () => {
    if (title.trim() || content.trim()) {
      dispatch(createNote({
        title: title.trim() || undefined,
        content: content.trim() || undefined,
      }));
      setTitle('');
      setContent('');
      setIsExpanded(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSubmit();
    }
  };

  const handleClickOutside = () => {
    if (title.trim() || content.trim()) {
      handleSubmit();
    } else {
      setIsExpanded(false);
    }
  };

  if (!isExpanded) {
    return (
      <div 
        className="max-w-2xl mx-auto mb-8 p-4 bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200 cursor-text"
        onClick={() => setIsExpanded(true)}
      >
        <p className="text-gray-500">Take a note...</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mb-8">
      <div className="bg-white rounded-lg border border-gray-200 shadow-md">
        <div className="p-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Title"
            className="w-full text-lg font-medium placeholder-gray-500 border-none outline-none mb-2"
            autoFocus
          />
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Take a note..."
            className="w-full placeholder-gray-500 border-none outline-none resize-none min-h-[80px]"
            rows={3}
          />
        </div>
        
        <div className="flex justify-end p-2 border-t border-gray-100">
          <button
            onClick={handleClickOutside}
            className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded transition-colors"
          >
            Close
          </button>
        </div>
      </div>
      
      {/* Invisible overlay to detect clicks outside */}
      <div 
        className="fixed inset-0 z-[-1]"
        onClick={handleClickOutside}
      />
    </div>
  );
}
