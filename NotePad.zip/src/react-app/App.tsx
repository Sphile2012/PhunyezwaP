import { BrowserRouter as Router, Routes, Route } from "react-router";
import { Provider } from 'react-redux';
import { store } from '@/react-app/store/store';
import HomePage from "@/react-app/pages/Home";

export default function App() {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
        </Routes>
      </Router>
    </Provider>
  );
}
