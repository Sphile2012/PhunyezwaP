import z from "zod";

export const NoteSchema = z.object({
  id: z.number(),
  title: z.string().nullable(),
  content: z.string().nullable(),
  color: z.string(),
  is_pinned: z.boolean(),
  is_archived: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateNoteSchema = z.object({
  title: z.string().optional(),
  content: z.string().optional(),
  color: z.string().optional(),
});

export const UpdateNoteSchema = z.object({
  title: z.string().optional(),
  content: z.string().optional(),
  color: z.string().optional(),
  is_pinned: z.boolean().optional(),
  is_archived: z.boolean().optional(),
});

export type Note = z.infer<typeof NoteSchema>;
export type CreateNote = z.infer<typeof CreateNoteSchema>;
export type UpdateNote = z.infer<typeof UpdateNoteSchema>;
