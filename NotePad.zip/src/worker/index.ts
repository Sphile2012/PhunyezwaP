import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { CreateNoteSchema, UpdateNoteSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

// Get all notes
app.get("/api/notes", async (c) => {
  const db = c.env.DB;
  
  const result = await db.prepare(`
    SELECT * FROM notes 
    WHERE is_archived = 0 
    ORDER BY is_pinned DESC, created_at DESC
  `).all();
  
  return c.json(result.results);
});

// Create a new note
app.post("/api/notes", zValidator("json", CreateNoteSchema), async (c) => {
  const db = c.env.DB;
  const data = c.req.valid("json");
  
  const result = await db.prepare(`
    INSERT INTO notes (title, content, color, created_at, updated_at)
    VALUES (?, ?, ?, datetime('now'), datetime('now'))
  `).bind(
    data.title || "",
    data.content || "",
    data.color || "#fef9c3"
  ).run();
  
  if (!result.success) {
    return c.json({ error: "Failed to create note" }, 500);
  }
  
  const note = await db.prepare("SELECT * FROM notes WHERE id = ?")
    .bind(result.meta.last_row_id).first();
  
  return c.json(note);
});

// Update a note
app.put("/api/notes/:id", zValidator("json", UpdateNoteSchema), async (c) => {
  const db = c.env.DB;
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates = [];
  const values = [];
  
  if (data.title !== undefined) {
    updates.push("title = ?");
    values.push(data.title);
  }
  if (data.content !== undefined) {
    updates.push("content = ?");
    values.push(data.content);
  }
  if (data.color !== undefined) {
    updates.push("color = ?");
    values.push(data.color);
  }
  if (data.is_pinned !== undefined) {
    updates.push("is_pinned = ?");
    values.push(data.is_pinned ? 1 : 0);
  }
  if (data.is_archived !== undefined) {
    updates.push("is_archived = ?");
    values.push(data.is_archived ? 1 : 0);
  }
  
  if (updates.length === 0) {
    return c.json({ error: "No fields to update" }, 400);
  }
  
  updates.push("updated_at = datetime('now')");
  values.push(id);
  
  const result = await db.prepare(`
    UPDATE notes SET ${updates.join(", ")} WHERE id = ?
  `).bind(...values).run();
  
  if (!result.success) {
    return c.json({ error: "Failed to update note" }, 500);
  }
  
  const note = await db.prepare("SELECT * FROM notes WHERE id = ?")
    .bind(id).first();
  
  return c.json(note);
});

// Delete a note
app.delete("/api/notes/:id", async (c) => {
  const db = c.env.DB;
  const id = c.req.param("id");
  
  const result = await db.prepare("DELETE FROM notes WHERE id = ?")
    .bind(id).run();
  
  if (!result.success) {
    return c.json({ error: "Failed to delete note" }, 500);
  }
  
  return c.json({ success: true });
});

export default app;
