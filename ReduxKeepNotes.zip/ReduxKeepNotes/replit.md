# Notes Application

## Overview

This is a full-stack notes application built with React, Express, and PostgreSQL. The application allows users to create, edit, delete, and manage notes with features like pinning, color coding, search functionality, and drag-and-drop reordering. The frontend uses a modern React stack with TypeScript, Tailwind CSS, and shadcn/ui components, while the backend provides a RESTful API built with Express.js.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **State Management**: Redux Toolkit for global state management with React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and custom color classes for notes
- **Routing**: Wouter for lightweight client-side routing
- **Drag & Drop**: react-beautiful-dnd for note reordering functionality
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Server Framework**: Express.js with TypeScript
- **API Design**: RESTful API with CRUD operations for notes
- **Database Layer**: Drizzle ORM for type-safe database operations
- **Schema Validation**: Zod schemas shared between frontend and backend
- **Error Handling**: Centralized error handling middleware
- **Development**: Hot reload with Vite integration in development mode

### Data Storage
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for database operations and migrations
- **Schema**: Single notes table with fields for title, content, color, pinning status, and timestamps
- **Fallback Storage**: In-memory storage implementation for development/testing

### Key Features
- **Note Management**: Full CRUD operations with real-time updates
- **Search**: Client-side search filtering through note titles and content
- **Organization**: Color coding and pinning system for note prioritization
- **User Experience**: Drag-and-drop reordering, modal-based editing, and responsive design
- **Data Validation**: Shared validation schemas between client and server

### Project Structure
- **Monorepo Layout**: Single repository with client, server, and shared directories
- **Shared Code**: Common TypeScript types and schemas in shared directory
- **Path Aliases**: Configured TypeScript path mapping for clean imports
- **Build Pipeline**: Vite for frontend bundling and esbuild for server compilation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless database driver
- **drizzle-orm**: TypeScript ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **@reduxjs/toolkit**: Predictable state container for JavaScript apps

### UI and Styling
- **@radix-ui/react-***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: CSS class variance management
- **lucide-react**: Icon library

### Development Tools
- **vite**: Frontend build tool and development server
- **tsx**: TypeScript execution environment for Node.js
- **@replit/vite-plugin-***: Replit-specific development plugins
- **react-beautiful-dnd**: Drag and drop functionality

### Validation and Forms
- **zod**: TypeScript-first schema validation
- **@hookform/resolvers**: Form validation resolvers for React Hook Form
- **react-hook-form**: Forms library for React