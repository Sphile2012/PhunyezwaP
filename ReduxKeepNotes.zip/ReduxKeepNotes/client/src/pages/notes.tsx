import { useEffect, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DragDropContext, Droppable, Draggable, DropResult, DroppableProvided, DraggableProvided, DraggableStateSnapshot } from 'react-beautiful-dnd';
import { Plus, Search, Grid3X3, List } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/store';
import { setNotes, setModalOpen, reorderNotes, filterNotes } from '@/store/notesSlice';
import type { Note } from '@shared/schema';
import NoteCard from '@/components/NoteCard';
import NoteModal from '@/components/NoteModal';
import SearchBar from '@/components/SearchBar';
import QuickAddNote from '@/components/QuickAddNote';

export default function NotesPage() {
  const dispatch = useAppDispatch();
  const { notes, searchQuery, isModalOpen } = useAppSelector((state) => state.notes);
  
  const filteredNotes = useMemo(() => {
    return filterNotes(notes, searchQuery);
  }, [notes, searchQuery]);

  const { data, isLoading } = useQuery<Note[]>({
    queryKey: ['/api/notes'],
  });

  useEffect(() => {
    if (!data) return;
    dispatch(setNotes(data));
  }, [data, dispatch]);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) {
      return;
    }

    const items = Array.from(filteredNotes);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Reorder the full notes array to maintain consistency
    const fullNotesReordered = notes.map(note => {
      const newIndex = items.findIndex(item => item.id === note.id);
      return newIndex !== -1 ? items[newIndex] : note;
    });
    dispatch(reorderNotes(fullNotesReordered));
  };

  const openModal = () => {
    dispatch(setModalOpen(true));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading notes...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Title */}
            <div className="flex items-center space-x-3">
              <div className="text-2xl text-yellow-500">📝</div>
              <h1 className="text-xl font-semibold text-foreground">My Notes</h1>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-2xl mx-8">
              <SearchBar />
            </div>

            {/* View Options */}
            <div className="flex items-center space-x-2">
              <button 
                className="p-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-accent-foreground transition-colors"
                data-testid="button-grid-view"
              >
                <Grid3X3 className="w-5 h-5" />
              </button>
              <button 
                className="p-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-accent-foreground transition-colors"
                data-testid="button-list-view"
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Add Note */}
        <QuickAddNote />

        {/* Notes Grid */}
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="notes-grid">
            {(provided: DroppableProvided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className="masonry-grid"
                data-testid="notes-grid"
              >
                {filteredNotes.map((note: Note, index: number) => (
                  <Draggable key={note.id} draggableId={note.id} index={index}>
                    {(provided: DraggableProvided, snapshot: DraggableStateSnapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className={`note-card ${snapshot.isDragging ? 'shadow-lg' : ''}`}
                      >
                        <NoteCard note={note} />
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        {filteredNotes.length === 0 && (
          <div className="text-center py-16" data-testid="empty-state">
            <div className="text-6xl mb-4">📝</div>
            <h3 className="text-lg font-medium text-foreground mb-2">No notes yet</h3>
            <p className="text-muted-foreground">Click the + button to create your first note</p>
          </div>
        )}
      </main>

      {/* Floating Action Button */}
      <button 
        onClick={openModal}
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-primary-foreground rounded-full fab hover:scale-105 transition-all duration-200 flex items-center justify-center z-40"
        data-testid="button-add-note"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Note Modal */}
      {isModalOpen && <NoteModal />}
    </div>
  );
}
