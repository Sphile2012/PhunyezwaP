import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { Note } from '@shared/schema';

interface NotesState {
  notes: Note[];
  searchQuery: string;
  isModalOpen: boolean;
  editingNote: Note | null;
  selectedColor: string;
}

const initialState: NotesState = {
  notes: [],
  searchQuery: '',
  isModalOpen: false,
  editingNote: null,
  selectedColor: 'default',
};

const notesSlice = createSlice({
  name: 'notes',
  initialState,
  reducers: {
    setNotes: (state, action: PayloadAction<Note[]>) => {
      state.notes = action.payload;
    },
    addNote: (state, action: PayloadAction<Note>) => {
      state.notes.push(action.payload);
    },
    updateNote: (state, action: PayloadAction<Note>) => {
      const index = state.notes.findIndex(note => note.id === action.payload.id);
      if (index !== -1) {
        state.notes[index] = action.payload;
      }
    },
    removeNote: (state, action: PayloadAction<string>) => {
      state.notes = state.notes.filter(note => note.id !== action.payload);
    },
    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;
    },
    setModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isModalOpen = action.payload;
      if (!action.payload) {
        state.editingNote = null;
        state.selectedColor = 'default';
      }
    },
    setEditingNote: (state, action: PayloadAction<Note | null>) => {
      state.editingNote = action.payload;
      state.selectedColor = action.payload?.color || 'default';
    },
    setSelectedColor: (state, action: PayloadAction<string>) => {
      state.selectedColor = action.payload;
    },
    reorderNotes: (state, action: PayloadAction<Note[]>) => {
      state.notes = action.payload;
    },
  },
});

export function filterNotes(notes: Note[], query: string): Note[] {
  if (!query.trim()) {
    return notes;
  }
  const lowerQuery = query.toLowerCase();
  return notes.filter(note => 
    (note.title ?? '').toLowerCase().includes(lowerQuery) ||
    (note.content ?? '').toLowerCase().includes(lowerQuery)
  );
}

export const {
  setNotes,
  addNote,
  updateNote,
  removeNote,
  setSearchQuery,
  setModalOpen,
  setEditingNote,
  setSelectedColor,
  reorderNotes,
} = notesSlice.actions;

export default notesSlice.reducer;
