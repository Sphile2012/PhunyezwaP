import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { setModalOpen, setSelectedColor, addNote, updateNote, setEditingNote } from '@/store/notesSlice';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAppDispatch, useAppSelector } from '@/store/store';
import type { Note, InsertNote } from '@shared/schema';

const colors = [
  { name: 'default', class: 'note-default' },
  { name: 'yellow', class: 'note-yellow' },
  { name: 'pink', class: 'note-pink' },
  { name: 'green', class: 'note-green' },
  { name: 'blue', class: 'note-blue' },
  { name: 'purple', class: 'note-purple' },
  { name: 'orange', class: 'note-orange' },
];

export default function NoteModal() {
  const dispatch = useAppDispatch();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { editingNote, selectedColor } = useAppSelector((state) => state.notes);
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    if (editingNote) {
      setTitle(editingNote.title);
      setContent(editingNote.content);
    } else {
      setTitle('');
      setContent('');
    }
  }, [editingNote]);

  const createNoteMutation = useMutation({
    mutationFn: async (noteData: InsertNote) => {
      const response = await apiRequest('POST', '/api/notes', noteData);
      return response.json();
    },
    onSuccess: (newNote) => {
      dispatch(addNote(newNote));
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      closeModal();
      toast({
        title: "Success",
        description: "Note created successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create note",
        variant: "destructive",
      });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async (noteData: Partial<Note>) => {
      const response = await apiRequest('PATCH', `/api/notes/${editingNote!.id}`, noteData);
      return response.json();
    },
    onSuccess: (updatedNote) => {
      dispatch(updateNote(updatedNote));
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      closeModal();
      toast({
        title: "Success",
        description: "Note updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update note",
        variant: "destructive",
      });
    },
  });

  const closeModal = () => {
    dispatch(setModalOpen(false));
    dispatch(setEditingNote(null));
    setTitle('');
    setContent('');
  };

  const handleSave = () => {
    if (!title.trim() && !content.trim()) {
      toast({
        title: "Error",
        description: "Please add a title or content",
        variant: "destructive",
      });
      return;
    }

    const noteData = {
      title: title.trim(),
      content: content.trim(),
      color: selectedColor,
      isPinned: editingNote?.isPinned || "false",
    };

    if (editingNote) {
      updateNoteMutation.mutate(noteData);
    } else {
      createNoteMutation.mutate(noteData);
    }
  };

  const handleColorSelect = (color: string) => {
    dispatch(setSelectedColor(color));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      closeModal();
    }
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      handleSave();
    }
  };

  const selectedColorClass = colors.find(c => c.name === selectedColor)?.class || 'note-default';

  return (
    <div className="fixed inset-0 z-50" onKeyDown={handleKeyDown}>
      <div className="fixed inset-0 bg-black/50" onClick={closeModal} data-testid="modal-backdrop" />
      <div className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:transform md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl">
        <div className={`${selectedColorClass} rounded-lg shadow-xl h-full md:h-auto flex flex-col`}>
          {/* Modal Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h2 className="text-lg font-semibold" data-testid="modal-title">
              {editingNote ? 'Edit Note' : 'New Note'}
            </h2>
            <div className="flex items-center space-x-2">
              {/* Color Options */}
              <div className="flex items-center space-x-1" data-testid="color-picker">
                {colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => handleColorSelect(color.name)}
                    className={`w-6 h-6 rounded-full ${color.class} border-2 ${
                      selectedColor === color.name ? 'border-gray-400' : 'border-transparent hover:border-gray-300'
                    } transition-colors`}
                    data-testid={`color-${color.name}`}
                  />
                ))}
              </div>
              <button 
                onClick={closeModal}
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="button-close-modal"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          </div>
          
          {/* Modal Body */}
          <div className="flex-1 p-4 space-y-4">
            <input 
              type="text" 
              placeholder="Note title..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full text-lg font-medium bg-transparent border-none focus:outline-none placeholder-muted-foreground"
              data-testid="input-note-title"
            />
            <textarea 
              placeholder="Take a note..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full h-64 bg-transparent border-none focus:outline-none resize-none placeholder-muted-foreground text-sm leading-relaxed"
              data-testid="input-note-content"
            />
          </div>
          
          {/* Modal Footer */}
          <div className="flex items-center justify-between p-4 border-t border-border">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">
                Ctrl+Enter to save, Esc to close
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={closeModal}
                className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-cancel"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                disabled={createNoteMutation.isPending || updateNoteMutation.isPending}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm disabled:opacity-50"
                data-testid="button-save"
              >
                {createNoteMutation.isPending || updateNoteMutation.isPending ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
