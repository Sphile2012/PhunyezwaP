import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { setModalOpen } from '@/store/notesSlice';

export default function QuickAddNote() {
  const dispatch = useDispatch();
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
    dispatch(setModalOpen(true));
  };

  return (
    <div className="mb-8 max-w-2xl mx-auto">
      <div className="bg-white rounded-lg border border-border p-4 shadow-sm hover:shadow-md transition-shadow note-hover">
        <input 
          type="text" 
          placeholder="Take a note..." 
          onFocus={handleFocus}
          className="w-full bg-transparent text-base focus:outline-none placeholder-muted-foreground"
          data-testid="input-quick-add"
        />
      </div>
    </div>
  );
}
