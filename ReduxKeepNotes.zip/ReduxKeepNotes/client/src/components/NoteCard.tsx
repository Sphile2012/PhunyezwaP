import { useDispatch } from 'react-redux';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Pin, Archive, Palette, Trash2 } from 'lucide-react';
import { setEditingNote, setModalOpen, removeNote, updateNote } from '@/store/notesSlice';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { Note } from '@shared/schema';

interface NoteCardProps {
  note: Note;
}

const colorClasses = {
  default: 'note-default',
  yellow: 'note-yellow',
  pink: 'note-pink', 
  green: 'note-green',
  blue: 'note-blue',
  purple: 'note-purple',
  orange: 'note-orange',
};

export default function NoteCard({ note }: NoteCardProps) {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateNoteMutation = useMutation({
    mutationFn: async (updatedNote: Partial<Note>) => {
      const response = await apiRequest('PATCH', `/api/notes/${note.id}`, updatedNote);
      return response.json();
    },
    onSuccess: (updatedNote) => {
      dispatch(updateNote(updatedNote));
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update note",
        variant: "destructive",
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/notes/${note.id}`);
    },
    onSuccess: () => {
      dispatch(removeNote(note.id));
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      toast({
        title: "Success",
        description: "Note deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to delete note",
        variant: "destructive",
      });
    },
  });

  const handleEdit = () => {
    dispatch(setEditingNote(note));
    dispatch(setModalOpen(true));
  };

  const handlePin = (e: React.MouseEvent) => {
    e.stopPropagation();
    const isPinned = note.isPinned === "true" ? "false" : "true";
    updateNoteMutation.mutate({ isPinned });
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    deleteNoteMutation.mutate();
  };

  const colorClass = colorClasses[note.color as keyof typeof colorClasses] || colorClasses.default;

  return (
    <div
      onClick={handleEdit}
      className={`${colorClass} rounded-lg p-4 cursor-pointer transition-all duration-200 note-hover group`}
      data-testid={`note-card-${note.id}`}
    >
      <div className="space-y-3">
        {note.title && (
          <h3 className="font-medium text-foreground leading-snug" data-testid={`note-title-${note.id}`}>
            {note.title}
          </h3>
        )}
        {note.content && (
          <div 
            className="text-sm text-foreground/90 whitespace-pre-wrap" 
            data-testid={`note-content-${note.id}`}
          >
            {note.content}
          </div>
        )}
        
        {/* Note Actions */}
        <div className="flex items-center justify-between pt-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex items-center space-x-1">
            <button 
              onClick={handlePin}
              className={`p-1.5 rounded-full hover:bg-black/10 transition-colors ${
                note.isPinned === "true" ? "text-blue-600" : "text-muted-foreground"
              }`}
              data-testid={`button-pin-${note.id}`}
            >
              <Pin className="w-3 h-3" />
            </button>
            <button 
              className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-muted-foreground"
              data-testid={`button-archive-${note.id}`}
            >
              <Archive className="w-3 h-3" />
            </button>
          </div>
          <div className="flex items-center space-x-1">
            <button 
              className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-muted-foreground"
              data-testid={`button-color-${note.id}`}
            >
              <Palette className="w-3 h-3" />
            </button>
            <button 
              onClick={handleDelete}
              className="p-1.5 rounded-full hover:bg-black/10 transition-colors text-muted-foreground"
              data-testid={`button-delete-${note.id}`}
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
