import { Search } from 'lucide-react';
import { setSearchQuery } from '@/store/notesSlice';
import { useAppDispatch, useAppSelector } from '@/store/store';

export default function SearchBar() {
  const dispatch = useAppDispatch();
  const searchQuery = useAppSelector((state) => state.notes.searchQuery);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch(setSearchQuery(e.target.value));
  };

  return (
    <div className="relative floating-search rounded-lg bg-white border border-border">
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
        <Search className="w-4 h-4 text-muted-foreground" />
      </div>
      <input 
        type="text" 
        placeholder="Search notes..." 
        value={searchQuery}
        onChange={handleSearch}
        className="w-full pl-10 pr-4 py-3 bg-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
        data-testid="input-search"
      />
    </div>
  );
}
